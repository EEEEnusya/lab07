//
// Created by yana on 18.05.2022.
//

#ifndef LAB07_KUB_H
#define LAB07_KUB_H

void kub(int a);

#endif //LAB07_KUB_H
