//
// Created by yana on 18.05.2022.
//

#include <kub.h>
void kub(int a){
    int b=a;
    a=a*a;
    a= b*a;
}